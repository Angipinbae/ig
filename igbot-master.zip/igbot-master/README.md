# igbot-PHP
Instagram bot using php

```sh
git clone https://github.com/nthanfp/igbot && cd igbot
bash run.sh
```
